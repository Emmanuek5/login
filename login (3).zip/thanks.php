<?php 
session_start();

	include("connection.php");
	include("functions.php");

	$user_data = check_login($con);

?>

<!DOCTYPE html>
<html>
<head>
	<title>Thank You</title>
	<style type="text/css">
		body{
			background: #4F6072;
		}
		h1{
			background: #4db6ac
		}
	</style>
</head>
<body>
	<center><h1>Thank You <?php echo $user_data['user_name']; ?> <br>
                We Will Get Back To You</h1></center>

</body>
</html>
